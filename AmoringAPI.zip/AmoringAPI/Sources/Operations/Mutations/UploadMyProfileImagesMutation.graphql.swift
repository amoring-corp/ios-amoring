// @generated
// This file was automatically generated and should not be edited.

@_exported import ApolloAPI

public class UploadMyProfileImagesMutation: GraphQLMutation {
  public static let operationName: String = "uploadMyProfileImages"
  public static let operationDocument: ApolloAPI.OperationDocument = .init(
    definition: .init(
      #"mutation uploadMyProfileImages($image0: Upload!) { uploadMyProfileImages(data: [{ sort: 0, file: $image0 }]) { __typename id profileId fileId sort file { __typename id name mimetype url path width height createdAt updatedAt } createdAt updatedAt } }"#
    ))

  public var image0: Upload

  public init(image0: Upload) {
    self.image0 = image0
  }

  public var __variables: Variables? { ["image0": image0] }

  public struct Data: AmoringAPI.SelectionSet {
    public let __data: DataDict
    public init(_dataDict: DataDict) { __data = _dataDict }

    public static var __parentType: ApolloAPI.ParentType { AmoringAPI.Objects.Mutation }
    public static var __selections: [ApolloAPI.Selection] { [
      .field("uploadMyProfileImages", [UploadMyProfileImage?].self, arguments: ["data": [[
        "sort": 0,
        "file": .variable("image0")
      ]]]),
    ] }

    public var uploadMyProfileImages: [UploadMyProfileImage?] { __data["uploadMyProfileImages"] }

    /// UploadMyProfileImage
    ///
    /// Parent Type: `UserProfileImage`
    public struct UploadMyProfileImage: AmoringAPI.SelectionSet {
      public let __data: DataDict
      public init(_dataDict: DataDict) { __data = _dataDict }

      public static var __parentType: ApolloAPI.ParentType { AmoringAPI.Objects.UserProfileImage }
      public static var __selections: [ApolloAPI.Selection] { [
        .field("__typename", String.self),
        .field("id", AmoringAPI.ID.self),
        .field("profileId", Int.self),
        .field("fileId", Int.self),
        .field("sort", Int.self),
        .field("file", File.self),
        .field("createdAt", AmoringAPI.DateTime?.self),
        .field("updatedAt", AmoringAPI.DateTime?.self),
      ] }

      public var id: AmoringAPI.ID { __data["id"] }
      public var profileId: Int { __data["profileId"] }
      public var fileId: Int { __data["fileId"] }
      public var sort: Int { __data["sort"] }
      public var file: File { __data["file"] }
      public var createdAt: AmoringAPI.DateTime? { __data["createdAt"] }
      public var updatedAt: AmoringAPI.DateTime? { __data["updatedAt"] }

      /// UploadMyProfileImage.File
      ///
      /// Parent Type: `File`
      public struct File: AmoringAPI.SelectionSet {
        public let __data: DataDict
        public init(_dataDict: DataDict) { __data = _dataDict }

        public static var __parentType: ApolloAPI.ParentType { AmoringAPI.Objects.File }
        public static var __selections: [ApolloAPI.Selection] { [
          .field("__typename", String.self),
          .field("id", AmoringAPI.ID.self),
          .field("name", String?.self),
          .field("mimetype", String?.self),
          .field("url", String?.self),
          .field("path", String?.self),
          .field("width", Int?.self),
          .field("height", Int?.self),
          .field("createdAt", AmoringAPI.DateTime?.self),
          .field("updatedAt", AmoringAPI.DateTime?.self),
        ] }

        public var id: AmoringAPI.ID { __data["id"] }
        public var name: String? { __data["name"] }
        public var mimetype: String? { __data["mimetype"] }
        public var url: String? { __data["url"] }
        public var path: String? { __data["path"] }
        public var width: Int? { __data["width"] }
        public var height: Int? { __data["height"] }
        public var createdAt: AmoringAPI.DateTime? { __data["createdAt"] }
        public var updatedAt: AmoringAPI.DateTime? { __data["updatedAt"] }
      }
    }
  }
}
