// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public struct UserProfileUpdateInput: InputObject {
  public private(set) var __data: InputDict

  public init(_ data: InputDict) {
    __data = data
  }

  public init(
    name: GraphQLNullable<String> = nil,
    age: GraphQLNullable<Int> = nil,
    birthYear: GraphQLNullable<Int> = nil,
    height: GraphQLNullable<Int> = nil,
    weight: GraphQLNullable<Int> = nil,
    mbti: GraphQLNullable<String> = nil,
    education: GraphQLNullable<String> = nil,
    bio: GraphQLNullable<String> = nil,
    gender: GraphQLNullable<GraphQLEnum<Gender>> = nil,
    images: GraphQLNullable<[UserProfileImageInput?]> = nil
  ) {
    __data = InputDict([
      "name": name,
      "age": age,
      "birthYear": birthYear,
      "height": height,
      "weight": weight,
      "mbti": mbti,
      "education": education,
      "bio": bio,
      "gender": gender,
      "images": images
    ])
  }

  public var name: GraphQLNullable<String> {
    get { __data["name"] }
    set { __data["name"] = newValue }
  }

  public var age: GraphQLNullable<Int> {
    get { __data["age"] }
    set { __data["age"] = newValue }
  }

  public var birthYear: GraphQLNullable<Int> {
    get { __data["birthYear"] }
    set { __data["birthYear"] = newValue }
  }

  public var height: GraphQLNullable<Int> {
    get { __data["height"] }
    set { __data["height"] = newValue }
  }

  public var weight: GraphQLNullable<Int> {
    get { __data["weight"] }
    set { __data["weight"] = newValue }
  }

  public var mbti: GraphQLNullable<String> {
    get { __data["mbti"] }
    set { __data["mbti"] = newValue }
  }

  public var education: GraphQLNullable<String> {
    get { __data["education"] }
    set { __data["education"] = newValue }
  }

  public var bio: GraphQLNullable<String> {
    get { __data["bio"] }
    set { __data["bio"] = newValue }
  }

  public var gender: GraphQLNullable<GraphQLEnum<Gender>> {
    get { __data["gender"] }
    set { __data["gender"] = newValue }
  }

  public var images: GraphQLNullable<[UserProfileImageInput?]> {
    get { __data["images"] }
    set { __data["images"] = newValue }
  }
}
