// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public enum Gender: String, EnumType {
  case male = "male"
  case female = "female"
}
