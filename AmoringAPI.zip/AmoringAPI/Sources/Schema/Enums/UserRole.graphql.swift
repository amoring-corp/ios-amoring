// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public enum UserRole: String, EnumType {
  case admin = "admin"
  case business = "business"
  case user = "user"
}
