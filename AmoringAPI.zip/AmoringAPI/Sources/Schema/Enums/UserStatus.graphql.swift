// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public enum UserStatus: String, EnumType {
  case unverified = "unverified"
  case active = "active"
  case inactive = "inactive"
}
